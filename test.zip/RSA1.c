#include <stdio.h>
//Define Functions
void welcomeMsg();

int main() {
	welcomeMsg();
}

//Functions
void welcomeMsg() {
	printf("*****************************************\n");
	printf("*\t%-25s\t*\n","ST2614 Assignment 1 done by:","*");
	printf("*\t%-25s\t*\n","Chong Jia Hao P1430615");
	printf("*\t%-25s\t*\n","Nicholas Koh P1431207");
	printf("*\t%-25s\t*\n","Class 2A / 21");
	printf("*****************************************\n\n");
	printf("Type 'e' to encrypt or 'd' to decrypt:\n");

}


//===========================Encryption Function by Nick====================================

//=============================End Encryption Function======================================


//===========================Decryption Function by Jia Hao====================================
//this is a test
//change test
//=============================End Decryption Function======================================