# Assignment1
RSA


Just edit the RSA1.c file

I've made the section for our own functions
